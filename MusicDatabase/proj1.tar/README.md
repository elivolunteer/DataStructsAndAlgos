# cs302_proj1
Compile command "g++ -o lib\_info lib\_info.cpp" 
